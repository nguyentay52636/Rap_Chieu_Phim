"use client"

import { MapPin, Route } from "lucide-react"
import { useDashboardStats } from "@/hooks/use-dashboard"
import { StatsCard, QuickActionsCard } from "@/components/dashboard"
import { Spinner } from "@/components/ui/spinner"

export default function AdminDashboard() {
  const { stats, isLoading } = useDashboardStats()

  if (isLoading) {
    return (
      <div className="flex h-full w-full items-center justify-center p-8">
        <Spinner className="h-8 w-8 text-primary" />
      </div>
    )
  }

  return (
    <div className="p-6 lg:p-8">
      <div className="mb-8">
        <h1 className="text-2xl font-semibold tracking-tight text-foreground">Dashboard</h1>
        <p className="mt-1 text-sm text-muted-foreground">
          Overview of your tours and points of interest.
        </p>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        <StatsCard
          title="Total POIs"
          value={stats.poiCount}
          icon={MapPin}
          href="/admin/pois"
          linkText="Manage POIs"
        />

        <StatsCard
          title="Total Tours"
          value={stats.tourCount}
          icon={Route}
          href="/admin/tours"
          linkText="Manage Tours"
        />

        <QuickActionsCard />
      </div>
    </div>
  )
}
