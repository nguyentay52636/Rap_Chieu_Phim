"use client"

import { useEffect } from "react"
import { useRouter } from "next/navigation"
import { useAuth } from "@/lib/auth-context"

/**
 * Hook for handling login form state and submission
 */
export function useLoginForm() {
  const router = useRouter()
  const { login, isAuthenticated, isLoading: authLoading } = useAuth()

  useEffect(() => {
    if (!authLoading && isAuthenticated) {
      router.replace("/admin")
    }
  }, [authLoading, isAuthenticated, router])

  async function handleLogin(email: string, password: string) {
    await login(email, password)
    router.replace("/admin")
  }

  return {
    isAuthLoading: authLoading,
    isAuthenticated,
    handleLogin,
  }
}

/**
 * Hook for protecting routes that require authentication
 */
export function useAuthGuard() {
  const router = useRouter()
  const { isAuthenticated, isLoading } = useAuth()

  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      router.replace("/login")
    }
  }, [isLoading, isAuthenticated, router])

  return {
    isLoading,
    isAuthenticated,
    shouldRender: !isLoading && isAuthenticated,
  }
}
