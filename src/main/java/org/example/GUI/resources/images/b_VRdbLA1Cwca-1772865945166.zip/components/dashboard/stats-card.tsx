"use client"

import Link from "next/link"
import { ArrowRight, type LucideIcon } from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

interface StatsCardProps {
  title: string
  value: number
  icon: LucideIcon
  href: string
  linkText: string
}

export function StatsCard({ title, value, icon: Icon, href, linkText }: StatsCardProps) {
  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between pb-2">
        <CardTitle className="text-sm font-medium text-muted-foreground">{title}</CardTitle>
        <Icon className="h-4 w-4 text-primary" />
      </CardHeader>
      <CardContent>
        <p className="text-3xl font-bold text-foreground">{value}</p>
        <Link
          href={href}
          className="mt-2 inline-flex items-center gap-1 text-sm text-primary hover:underline"
        >
          {linkText} <ArrowRight className="h-3 w-3" />
        </Link>
      </CardContent>
    </Card>
  )
}
