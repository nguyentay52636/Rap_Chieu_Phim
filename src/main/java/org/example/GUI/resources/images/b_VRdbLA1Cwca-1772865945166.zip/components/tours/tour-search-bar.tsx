"use client"

import { Search, LayoutGrid, LayoutList } from "lucide-react"
import { Input } from "@/components/ui/input"
import type { ViewMode } from "@/hooks/use-tours"

interface TourSearchBarProps {
  search: string
  onSearchChange: (value: string) => void
  viewMode: ViewMode
  onViewModeChange: (mode: ViewMode) => void
}

export function TourSearchBar({
  search,
  onSearchChange,
  viewMode,
  onViewModeChange,
}: TourSearchBarProps) {
  return (
    <div className="flex items-center gap-2 border-b border-border px-5 py-3">
      <div className="relative flex-1">
        <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
        <Input
          placeholder="Search by name or description..."
          value={search}
          onChange={(e) => onSearchChange(e.target.value)}
          className="pl-9"
        />
      </div>
      <ViewModeToggle viewMode={viewMode} onViewModeChange={onViewModeChange} />
    </div>
  )
}

interface ViewModeToggleProps {
  viewMode: ViewMode
  onViewModeChange: (mode: ViewMode) => void
}

function ViewModeToggle({ viewMode, onViewModeChange }: ViewModeToggleProps) {
  return (
    <div className="flex items-center rounded-md border border-border">
      <button
        onClick={() => onViewModeChange("grid")}
        className={`flex items-center justify-center rounded-l-md p-2 transition-colors ${
          viewMode === "grid"
            ? "bg-muted text-foreground"
            : "text-muted-foreground hover:text-foreground"
        }`}
        aria-label="Grid view"
      >
        <LayoutGrid className="h-4 w-4" />
      </button>
      <button
        onClick={() => onViewModeChange("list")}
        className={`flex items-center justify-center rounded-r-md p-2 transition-colors ${
          viewMode === "list"
            ? "bg-muted text-foreground"
            : "text-muted-foreground hover:text-foreground"
        }`}
        aria-label="List view"
      >
        <LayoutList className="h-4 w-4" />
      </button>
    </div>
  )
}
