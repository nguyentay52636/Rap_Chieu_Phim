"use client"

import type { POI } from "@/lib/types"
import {
  Table,
  TableBody,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import { POITableRow } from "./poi-table-row"
import { POIEmptyState } from "./poi-empty-state"

interface POIDataTableProps {
  pois: POI[]
  selectedPoi: POI | null
  onSelect: (poi: POI) => void
  onEdit: (poi: POI) => void
  onDelete: (poi: POI) => void
  onViewOnMap: (poi: POI) => void
  hasSearchFilter?: boolean
}

export function POIDataTable({
  pois,
  selectedPoi,
  onSelect,
  onEdit,
  onDelete,
  onViewOnMap,
  hasSearchFilter = false,
}: POIDataTableProps) {
  if (pois.length === 0) {
    return <POIEmptyState hasSearchFilter={hasSearchFilter} />
  }

  return (
    <div className="overflow-auto">
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead className="w-[240px]">Name</TableHead>
            <TableHead className="w-[120px]">Category</TableHead>
            <TableHead className="hidden lg:table-cell">Coordinates</TableHead>
            <TableHead className="w-[60px] text-right">Actions</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {pois.map((poi) => (
            <POITableRow
              key={poi.id}
              poi={poi}
              isSelected={selectedPoi?.id === poi.id}
              onSelect={onSelect}
              onEdit={onEdit}
              onDelete={onDelete}
              onViewOnMap={onViewOnMap}
            />
          ))}
        </TableBody>
      </Table>
    </div>
  )
}
