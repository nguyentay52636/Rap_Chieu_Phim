"use client"

import { usePathname } from "next/navigation"
import { MapPin, Route, LayoutDashboard } from "lucide-react"
import { useAuth } from "@/lib/auth-context"
import { SidebarNavItem, SidebarUserFooter } from "@/components/layout"

const NAV_ITEMS = [
  { label: "Dashboard", href: "/admin", icon: LayoutDashboard },
  { label: "POIs", href: "/admin/pois", icon: MapPin },
  { label: "Tours", href: "/admin/tours", icon: Route },
] as const

export function AdminSidebar() {
  const pathname = usePathname()
  const { user, logout } = useAuth()

  function isActive(href: string) {
    return href === "/admin" ? pathname === "/admin" : pathname.startsWith(href)
  }

  return (
    <aside className="flex h-screen w-64 flex-col bg-sidebar text-sidebar-foreground border-r border-sidebar-border">
      {/* Logo */}
      <div className="flex items-center gap-3 px-6 py-5 border-b border-sidebar-border">
        <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-primary">
          <Route className="h-5 w-5 text-primary-foreground" />
        </div>
        <div>
          <h1 className="text-sm font-semibold tracking-tight">Tour Manager</h1>
          <p className="text-xs text-sidebar-foreground/60">Admin Panel</p>
        </div>
      </div>

      {/* Navigation */}
      <nav className="flex-1 px-3 py-4">
        <p className="px-3 mb-2 text-[11px] font-medium uppercase tracking-wider text-sidebar-foreground/40">
          Menu
        </p>
        <ul className="flex flex-col gap-1">
          {NAV_ITEMS.map((item) => (
            <SidebarNavItem
              key={item.href}
              href={item.href}
              label={item.label}
              icon={item.icon}
              isActive={isActive(item.href)}
            />
          ))}
        </ul>
      </nav>

      {/* User Footer */}
      <SidebarUserFooter user={user} onLogout={logout} />
    </aside>
  )
}
