"use client"

import type { POI } from "@/lib/types"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"

interface POIDeleteDialogProps {
  poi: POI | null
  onClose: () => void
  onConfirm: () => void
}

export function POIDeleteDialog({ poi, onClose, onConfirm }: POIDeleteDialogProps) {
  return (
    <AlertDialog open={!!poi} onOpenChange={(open) => !open && onClose()}>
      <AlertDialogContent>
        <AlertDialogHeader>
          <AlertDialogTitle>Delete POI</AlertDialogTitle>
          <AlertDialogDescription>
            Are you sure you want to delete &quot;{poi?.name}&quot;? This action cannot be undone.
            Tours referencing this POI may be affected.
          </AlertDialogDescription>
        </AlertDialogHeader>
        <AlertDialogFooter>
          <AlertDialogCancel>Cancel</AlertDialogCancel>
          <AlertDialogAction
            onClick={onConfirm}
            className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
          >
            Delete
          </AlertDialogAction>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  )
}
