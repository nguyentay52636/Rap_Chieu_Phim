"use client"

import { Plus, Route, CheckCircle2, FileText } from "lucide-react"
import { Button } from "@/components/ui/button"
import type { TourStats, FilterStatus } from "@/hooks/use-tours"

interface TourListHeaderProps {
  stats: TourStats
  filterStatus: FilterStatus
  onFilterChange: (status: FilterStatus) => void
  onCreateClick: () => void
  isLoading: boolean
}

export function TourListHeader({
  stats,
  filterStatus,
  onFilterChange,
  onCreateClick,
  isLoading,
}: TourListHeaderProps) {
  return (
    <div className="border-b border-border px-5 py-4">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-lg font-semibold text-foreground">Tour Management</h1>
          <p className="mt-0.5 text-xs text-muted-foreground">
            Create and manage tour itineraries
          </p>
        </div>
        <Button size="sm" onClick={onCreateClick} className="gap-1.5">
          <Plus className="h-4 w-4" /> New Tour
        </Button>
      </div>

      {!isLoading && (
        <div className="mt-4 flex items-center gap-3">
          <FilterButton
            active={filterStatus === "all"}
            onClick={() => onFilterChange("all")}
            icon={<Route className="h-3.5 w-3.5" />}
            label={`All (${stats.total})`}
            variant="default"
          />
          <FilterButton
            active={filterStatus === "published"}
            onClick={() => onFilterChange("published")}
            icon={<CheckCircle2 className="h-3.5 w-3.5" />}
            label={`Published (${stats.published})`}
            variant="success"
          />
          <FilterButton
            active={filterStatus === "draft"}
            onClick={() => onFilterChange("draft")}
            icon={<FileText className="h-3.5 w-3.5" />}
            label={`Draft (${stats.draft})`}
            variant="warning"
          />
        </div>
      )}
    </div>
  )
}

interface FilterButtonProps {
  active: boolean
  onClick: () => void
  icon: React.ReactNode
  label: string
  variant: "default" | "success" | "warning"
}

function FilterButton({ active, onClick, icon, label, variant }: FilterButtonProps) {
  const baseClasses = "flex items-center gap-1.5 rounded-md px-2.5 py-1.5 text-xs font-medium transition-colors"
  
  const activeClasses = {
    default: "bg-primary/10 text-primary",
    success: "bg-success/10 text-success",
    warning: "bg-warning/10 text-warning",
  }
  
  const inactiveClasses = "text-muted-foreground hover:text-foreground hover:bg-muted"

  return (
    <button
      onClick={onClick}
      className={`${baseClasses} ${active ? activeClasses[variant] : inactiveClasses}`}
    >
      {icon}
      {label}
    </button>
  )
}
