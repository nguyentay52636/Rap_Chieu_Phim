"use client"

import { MapPin, Search } from "lucide-react"

interface POIEmptyStateProps {
  hasSearchFilter?: boolean
}

export function POIEmptyState({ hasSearchFilter = false }: POIEmptyStateProps) {
  if (hasSearchFilter) {
    return (
      <div className="flex flex-col items-center justify-center py-16 text-center">
        <div className="rounded-full bg-muted p-4">
          <Search className="h-8 w-8 text-muted-foreground" />
        </div>
        <p className="mt-4 text-sm font-medium text-foreground">No POIs found</p>
        <p className="mt-1 max-w-[240px] text-xs text-muted-foreground">
          Try adjusting your search or filter to find what you&apos;re looking for.
        </p>
      </div>
    )
  }

  return (
    <div className="flex flex-col items-center justify-center py-16 text-center">
      <div className="rounded-full bg-primary/10 p-4">
        <MapPin className="h-8 w-8 text-primary" />
      </div>
      <p className="mt-4 text-sm font-medium text-foreground">No POIs yet</p>
      <p className="mt-1 max-w-[240px] text-xs text-muted-foreground">
        Create your first point of interest by clicking the &quot;Add POI&quot; button and selecting a location on the map.
      </p>
    </div>
  )
}
