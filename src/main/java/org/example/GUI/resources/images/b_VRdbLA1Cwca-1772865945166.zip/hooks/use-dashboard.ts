"use client"

import { useEffect, useState } from "react"
import { fetchPOIs, fetchTours } from "@/lib/api"

interface DashboardStats {
  poiCount: number
  tourCount: number
  publishedTourCount: number
  majorPoiCount: number
}

export function useDashboardStats() {
  const [stats, setStats] = useState<DashboardStats>({
    poiCount: 0,
    tourCount: 0,
    publishedTourCount: 0,
    majorPoiCount: 0,
  })
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    async function load() {
      try {
        const [pois, tours] = await Promise.all([fetchPOIs(), fetchTours()])
        setStats({
          poiCount: pois.length,
          tourCount: tours.length,
          publishedTourCount: tours.filter((t) => t.status === "published").length,
          majorPoiCount: pois.filter((p) => p.category === "major").length,
        })
      } finally {
        setIsLoading(false)
      }
    }
    load()
  }, [])

  return { stats, isLoading }
}
