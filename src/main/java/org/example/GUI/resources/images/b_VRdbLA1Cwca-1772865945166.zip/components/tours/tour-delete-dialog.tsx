"use client"

import type { Tour } from "@/lib/types"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"

interface TourDeleteDialogProps {
  tour: Tour | null
  open: boolean
  onOpenChange: (open: boolean) => void
  onConfirm: () => void
}

export function TourDeleteDialog({
  tour,
  open,
  onOpenChange,
  onConfirm,
}: TourDeleteDialogProps) {
  return (
    <AlertDialog open={open} onOpenChange={onOpenChange}>
      <AlertDialogContent>
        <AlertDialogHeader>
          <AlertDialogTitle>Delete Tour</AlertDialogTitle>
          <AlertDialogDescription>
            Are you sure you want to delete &quot;{tour?.name}&quot;? This action cannot
            be undone. This tour has {tour?.pois.length ?? 0} POI stops that will be
            unlinked.
          </AlertDialogDescription>
        </AlertDialogHeader>
        <AlertDialogFooter>
          <AlertDialogCancel>Cancel</AlertDialogCancel>
          <AlertDialogAction
            onClick={onConfirm}
            className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
          >
            Delete
          </AlertDialogAction>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  )
}
