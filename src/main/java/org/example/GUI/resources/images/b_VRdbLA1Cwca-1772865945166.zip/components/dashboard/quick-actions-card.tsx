"use client"

import Link from "next/link"
import { MapPin, Route } from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"

export function QuickActionsCard() {
  return (
    <Card className="md:col-span-2 lg:col-span-1">
      <CardHeader className="pb-2">
        <CardTitle className="text-sm font-medium text-muted-foreground">Quick Actions</CardTitle>
      </CardHeader>
      <CardContent className="flex flex-col gap-2">
        <Button asChild variant="outline" className="justify-start">
          <Link href="/admin/pois">
            <MapPin className="mr-2 h-4 w-4" /> Add New POI
          </Link>
        </Button>
        <Button asChild variant="outline" className="justify-start">
          <Link href="/admin/tours">
            <Route className="mr-2 h-4 w-4" /> Create New Tour
          </Link>
        </Button>
      </CardContent>
    </Card>
  )
}
