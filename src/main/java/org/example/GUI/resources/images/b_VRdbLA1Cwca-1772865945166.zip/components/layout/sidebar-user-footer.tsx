"use client"

import { LogOut } from "lucide-react"
import type { AdminUser } from "@/lib/types"

interface SidebarUserFooterProps {
  user: AdminUser | null
  onLogout: () => void
}

export function SidebarUserFooter({ user, onLogout }: SidebarUserFooterProps) {
  return (
    <div className="border-t border-sidebar-border px-4 py-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3 min-w-0">
          <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-sidebar-accent text-xs font-semibold text-sidebar-primary">
            {user?.name?.charAt(0) ?? "A"}
          </div>
          <div className="min-w-0">
            <p className="truncate text-sm font-medium">{user?.name ?? "Admin"}</p>
            <p className="truncate text-xs text-sidebar-foreground/50">{user?.email ?? ""}</p>
          </div>
        </div>
        <button
          onClick={onLogout}
          className="rounded-md p-1.5 text-sidebar-foreground/50 transition-colors hover:bg-sidebar-accent hover:text-sidebar-foreground"
          aria-label="Log out"
        >
          <LogOut className="h-4 w-4" />
        </button>
      </div>
    </div>
  )
}
