"use client"

import { useState, useCallback } from "react"
import type { Tour, CreateTourPayload } from "@/lib/types"
import { useTours, useTourActions } from "@/hooks/use-tours"
import {
  TourListHeader,
  TourSearchBar,
  TourGridCard,
  TourListRow,
  TourEmptyState,
  TourDetailEmptyState,
  TourLoadingState,
  TourDeleteDialog,
  TourFormDialog,
  TourDetailPanel,
} from "@/components/tours"

export default function ToursPage() {
  // Data and filtering state from hook
  const {
    allPois,
    isLoading,
    search,
    setSearch,
    viewMode,
    setViewMode,
    filterStatus,
    setFilterStatus,
    filteredTours,
    stats,
    loadData,
    getPoiName,
  } = useTours()

  // UI state
  const [formOpen, setFormOpen] = useState(false)
  const [editingTour, setEditingTour] = useState<Tour | null>(null)
  const [deleteTarget, setDeleteTarget] = useState<Tour | null>(null)
  const [viewingTour, setViewingTour] = useState<Tour | null>(null)

  // Actions from hook
  const { handleCreate, handleUpdate, handleDuplicate, handleDelete } = useTourActions(loadData)

  // Event handlers
  const openCreateForm = useCallback(() => {
    setEditingTour(null)
    setFormOpen(true)
  }, [])

  const openEditForm = useCallback((tour: Tour) => {
    setEditingTour(tour)
    setFormOpen(true)
  }, [])

  const closeForm = useCallback(() => {
    setFormOpen(false)
    setEditingTour(null)
  }, [])

  const handleFormSubmit = useCallback(
    async (data: CreateTourPayload) => {
      if (editingTour) {
        const updated = await handleUpdate(editingTour.id, data)
        if (viewingTour?.id === editingTour.id) {
          setViewingTour(updated)
        }
      } else {
        await handleCreate(data)
      }
    },
    [editingTour, viewingTour, handleCreate, handleUpdate]
  )

  const confirmDelete = useCallback(async () => {
    if (!deleteTarget) return
    await handleDelete(deleteTarget)
    if (viewingTour?.id === deleteTarget.id) {
      setViewingTour(null)
    }
    setDeleteTarget(null)
  }, [deleteTarget, viewingTour, handleDelete])

  return (
    <div className="flex h-full flex-col lg:flex-row">
      {/* Left: Tours list */}
      <div className="flex h-full w-full flex-col border-r border-border lg:w-[520px] xl:w-[580px]">
        <TourListHeader
          stats={stats}
          filterStatus={filterStatus}
          onFilterChange={setFilterStatus}
          onCreateClick={openCreateForm}
          isLoading={isLoading}
        />

        <TourSearchBar
          search={search}
          onSearchChange={setSearch}
          viewMode={viewMode}
          onViewModeChange={setViewMode}
        />

        {/* Tour cards/list */}
        <div className="flex-1 overflow-y-auto">
          {isLoading ? (
            <TourLoadingState />
          ) : filteredTours.length === 0 ? (
            <TourEmptyState
              search={search}
              filterStatus={filterStatus}
              onCreateClick={openCreateForm}
            />
          ) : viewMode === "grid" ? (
            <div className="flex flex-col gap-3 p-4">
              {filteredTours.map((tour) => (
                <TourGridCard
                  key={tour.id}
                  tour={tour}
                  isSelected={viewingTour?.id === tour.id}
                  allPois={allPois}
                  getPoiName={getPoiName}
                  onClick={() => setViewingTour(tour)}
                  onEdit={() => openEditForm(tour)}
                  onDuplicate={() => handleDuplicate(tour)}
                  onDelete={() => setDeleteTarget(tour)}
                />
              ))}
            </div>
          ) : (
            <div className="flex flex-col">
              {filteredTours.map((tour, idx) => (
                <TourListRow
                  key={tour.id}
                  tour={tour}
                  isSelected={viewingTour?.id === tour.id}
                  getPoiName={getPoiName}
                  isLast={idx === filteredTours.length - 1}
                  onClick={() => setViewingTour(tour)}
                  onEdit={() => openEditForm(tour)}
                  onDuplicate={() => handleDuplicate(tour)}
                  onDelete={() => setDeleteTarget(tour)}
                />
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Right: Detail panel */}
      <div className="flex-1 min-h-[300px]">
        {viewingTour ? (
          <TourDetailPanel
            tour={viewingTour}
            allPois={allPois}
            getPoiName={getPoiName}
            onEdit={() => openEditForm(viewingTour)}
            onClose={() => setViewingTour(null)}
          />
        ) : (
          <TourDetailEmptyState />
        )}
      </div>

      {/* Form Dialog */}
      <TourFormDialog
        open={formOpen}
        onOpenChange={(o) => !o && closeForm()}
        tour={editingTour}
        allPois={allPois}
        onSubmit={handleFormSubmit}
      />

      {/* Delete Confirmation */}
      <TourDeleteDialog
        tour={deleteTarget}
        open={!!deleteTarget}
        onOpenChange={(o) => !o && setDeleteTarget(null)}
        onConfirm={confirmDelete}
      />
    </div>
  )
}
