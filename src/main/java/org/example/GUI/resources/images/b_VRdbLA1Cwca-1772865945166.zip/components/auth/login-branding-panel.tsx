"use client"

import { Route } from "lucide-react"

export function LoginBrandingPanel() {
  return (
    <div className="hidden lg:flex lg:w-1/2 flex-col justify-between bg-sidebar text-sidebar-foreground p-12">
      <div className="flex items-center gap-3">
        <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary">
          <Route className="h-5 w-5 text-primary-foreground" />
        </div>
        <span className="text-lg font-semibold tracking-tight">Tour Manager</span>
      </div>

      <div>
        <h2 className="text-3xl font-semibold leading-tight tracking-tight text-balance">
          Manage your tours and points of interest with ease.
        </h2>
        <p className="mt-4 text-base leading-relaxed text-sidebar-foreground/60">
          Create, organize, and publish tour routes. Map your points of interest and build
          engaging itineraries for visitors.
        </p>
      </div>

      <p className="text-xs text-sidebar-foreground/40">
        Tour Admin Dashboard &middot; Controlled Vibe Coding POC
      </p>
    </div>
  )
}
