"use client"

import { useState } from "react"
import { useLoginForm } from "@/hooks/use-auth"
import { LoginBrandingPanel, LoginFormFields } from "@/components/auth"
import { Spinner } from "@/components/ui/spinner"

export function LoginForm() {
  const { isAuthLoading, handleLogin } = useLoginForm()

  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [showPassword, setShowPassword] = useState(false)
  const [error, setError] = useState("")
  const [isSubmitting, setIsSubmitting] = useState(false)

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault()
    setError("")

    if (!email.trim() || !password.trim()) {
      setError("Please enter both email and password.")
      return
    }

    setIsSubmitting(true)
    try {
      await handleLogin(email, password)
    } catch {
      setError("Invalid email or password. Please try again.")
    } finally {
      setIsSubmitting(false)
    }
  }

  if (isAuthLoading) {
    return (
      <div className="flex h-screen w-full items-center justify-center bg-background">
        <Spinner className="h-8 w-8 text-primary" />
      </div>
    )
  }

  return (
    <div className="flex min-h-screen">
      <LoginBrandingPanel />
      <LoginFormFields
        email={email}
        password={password}
        showPassword={showPassword}
        error={error}
        isSubmitting={isSubmitting}
        onEmailChange={setEmail}
        onPasswordChange={setPassword}
        onTogglePassword={() => setShowPassword(!showPassword)}
        onSubmit={onSubmit}
      />
    </div>
  )
}
